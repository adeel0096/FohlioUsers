import { ModuleRegistry, AllCommunityModule } from "ag-grid-community";

// Register all free community features
ModuleRegistry.registerModules([AllCommunityModule]);